/*
** EPITECH PROJECT, 2025
** Paradigms Seminar
** File description:
** Day 10
*/

#pragma once

class Hack
{
private:
    bool _0;
    unsigned _1;

public:
    virtual ~Hack() = default;

    void hack(unsigned _) { _1 = _; }
};
